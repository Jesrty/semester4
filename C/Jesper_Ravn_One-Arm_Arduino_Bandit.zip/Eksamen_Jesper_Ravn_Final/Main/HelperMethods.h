#ifndef HELPERMETHODS_H_INCLUDED
#define HELPERMETHODS_H_INCLUDED

unsigned int getUserInput();

#endif 
